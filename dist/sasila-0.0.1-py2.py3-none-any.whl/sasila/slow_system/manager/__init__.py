#!/usr/bin/env python
# -*- coding: utf-8 -*-
from sasila.slow_system.manager.spider_manager import SpiderManager
import sys

reload(sys)
sys.setdefaultencoding('utf-8')

manager = SpiderManager()
