#!/usr/bin/env python
# -*- coding: utf-8 -*-

# http://kafka-python.readthedocs.io/en/master/
import sys
from kafka import KafkaProducer

reload(sys)
sys.setdefaultencoding('utf-8')

producer = KafkaProducer(bootstrap_servers='192.168.3.212:9092,192.168.3.211:9092', retries=5)


def send_message(topic, content):
    producer.send(topic, content)
    producer.flush()
