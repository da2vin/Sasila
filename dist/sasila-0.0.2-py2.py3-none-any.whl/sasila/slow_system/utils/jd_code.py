#!/usr/bin/env python
# -*- coding: utf-8 -*-

SUCCESS = "0"
NEED_SMS = "1"
SMS_FAIL = "2"
