#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sasila.settings

__version__ = '0.0.4'
