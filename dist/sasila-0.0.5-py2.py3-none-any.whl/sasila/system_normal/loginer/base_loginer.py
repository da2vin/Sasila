#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys

reload(sys)
sys.setdefaultencoding('utf-8')


class BaseLoginer(object):
    def login(self, account, password):
        cookies = ""
        return cookies
